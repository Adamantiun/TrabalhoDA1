var searchData=
[
  ['readorders_0',['readOrders',['../class_controller.html#a5141a46dd52c59f2bcc9a211aaed4d0b',1,'Controller']]],
  ['readtrucks_1',['readTrucks',['../class_controller.html#a13ef5f33a9ce80c704e8366775c43aeb',1,'Controller']]]
];
