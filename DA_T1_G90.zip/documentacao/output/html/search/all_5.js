var searchData=
[
  ['processselectedorders_0',['processSelectedOrders',['../class_controller.html#a628d554ef6e61861184af3f151d0444b',1,'Controller']]],
  ['processtruck_1',['processTruck',['../class_controller.html#af02e8c5425784e3252c7b16b7ff750fd',1,'Controller']]]
];
