#include <iostream>
#include "Interface/System.h"

int main() {
    System system = System();
    return 0;
}

